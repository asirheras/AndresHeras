﻿Contesta a las siguientes preguntas en el README.md de este repositorio. Utiliza el lenguaje Markdown y el editor Visual Studio Code con su plugin correspondiente:

Indica qué es un lenguaje de marcas

Características generales de los lenguajes de marcas.

Clasifica los lenguajes de marcas e identifica los más relevantes.

Indica los distintos ámbitos de aplicación de los lenguajes de marcas.

Se ha reconocido la necesidad y los ámbitos específicos de aplicación de un lenguaje de marcas de propósito general.

Inserta un trozo de código de cada uno de los lenguajes de marcas que se indican a continuación. Añadir a cada trozo de código un pequeño resumen sobre su estructura y la aplicación asociada que los procesa:

HTML

iCal

vCard

KML

RSS

De interés:

lenguajes-de-marcas-tipos-y-clasificacion-de-los-mas-relevantes (http://www.docencia.taboadaleon.es/)

Lenguaje\_de\_marcado (www.ecured.cu)

Características (wikipedia)

Clasificación (http://mural.uv.es/)

ventajas\_para\_el\_tratamiento\_de\_la\_informacion

clasificacion
